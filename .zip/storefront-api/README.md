# STOREFRONT_API

## DATABASE SETUP
* Login to postgres user on your terminal 
> sudo -u postgres psql

* Create  `full_stack_user` using the command below:
> CREATE USER full_stack_user WITH PASSWORD 'password123' SUPERUSER;

* Create `storefront` database in psql with user. This is the development database.
> CREATE DATABASE storefront;
> GRANT ALL PRIVILEGES ON DATABASE yourdbname TO youruser;

* Create `storefront-test` database in psql with the user above. This is the testing database.

## DEPENDENCY INSTALL
* Run `npm install` on your terminal to install the dependecies. 

## MIGRATIONS
* Run `db-migrate --env dev up` to migrate the tables to the created database.

## COMPILATION AND RUNNING
* Run `npm start` to start the application (build version)
* Run `npm watch` to start the application (transpiled version)
    
## TESTING
* Run `npm test` to run all the tests.